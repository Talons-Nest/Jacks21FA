//This is where all the stored player data goes.

public class PlayerData
{    //Constructer and properties for Player information. Health, Attack Power, ScriptPoints

}

