public abstract class MonsterData
{    
    
    //Create a Constructor for a general monster.

    //Abstract method for monster attack AI.

    //Constructor with properties already set for Toaster enemy. 

    //Constructer with properties already set for Coffee Machine enemy.

    //Constructor with properties already set for Office Zombie enemy.

    //Constructor with properties already set for NAC Boss.

    

   

}