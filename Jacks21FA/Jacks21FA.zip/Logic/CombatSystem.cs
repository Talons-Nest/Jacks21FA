//This is where all the logic for the combat system will go.

public class Combat
{
    //First import both the player and the enemy. Get Set their properties, sprites, and the players choices.

    //Create a while loop that is running as long as both characters have more than 0 HP the fight continues. Alternate turns. 

    //Call the insantiated enemies AI. Give the player a turn with their action choices. 

    //Dice rolls should be used for both. Should that method be stored here? Called here? 
}