//This is where item use logic is stored.

public class Item
{
    
}