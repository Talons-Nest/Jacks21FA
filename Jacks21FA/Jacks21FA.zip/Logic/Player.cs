//This is where Player logic goes.

public class Player

{
    public void Attack()
    {
        
    }

    public void Item()
    {

    }

    public void ScriptIt()
    {

    }

    public void RunAway()

    {

    }
}