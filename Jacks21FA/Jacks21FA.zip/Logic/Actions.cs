//This is where methods like Attack, HealHP, HealSP, RunAway, Die will be called.
public class Actions()
{
    
}