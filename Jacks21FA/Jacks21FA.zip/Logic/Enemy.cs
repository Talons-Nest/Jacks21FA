//This is where all the enemy logic is stored.
public class Enemy

{
   public void EnemyAttack()
    {
        
    }

    public void EnemyItem()
    {

    }

    public void EnemyPower()
    {

    }

  
}